package br.com.facility;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FacilityApplicationTests {

	@Test
	void contextLoads() {
	}

}
